    c.owner      = ${table_schema}
AND c.table_name = ${table_name}