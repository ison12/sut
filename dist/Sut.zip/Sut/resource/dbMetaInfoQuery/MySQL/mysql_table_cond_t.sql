    C.TABLE_SCHEMA = ${table_schema}
AND C.TABLE_NAME   = ${table_name}