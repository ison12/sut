    S.schema_name = ${table_schema}
AND T.table_name   = ${table_name}