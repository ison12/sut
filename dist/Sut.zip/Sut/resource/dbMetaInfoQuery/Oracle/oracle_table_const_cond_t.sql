    const.owner      = ${table_schema}
AND const.table_name = ${table_name}