    const.table_schema = ${table_schema}
AND const.table_name   = ${table_name}