    S.schema_name = ${table_schema}
AND Ttable_name   = ${table_name}