    c.table_schema = ${table_schema}
AND c.table_name   = ${table_name}